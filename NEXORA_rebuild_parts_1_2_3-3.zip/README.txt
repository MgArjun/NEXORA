NEXORA rebuild

1. Use part1.html as the new index.html.
2. Paste the contents of part2.html immediately before </body> in part1.html.
3. Paste the contents of part3.html immediately after Part 2 and before </body>.

Part 2/3 are progressive enhancements. Supabase tables/RPCs from the existing NEXORA backend are expected.
